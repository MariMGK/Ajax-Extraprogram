﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default3 : System.Web.UI.Page
{
    public class customer
    {
        public string OrderId { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
    }
    public class orders
    {
        public string OrderId { get; set; }
        public string OrderName { get; set; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        ArrayList arrList = new ArrayList();
        ArrayList arrList1 = new ArrayList();
        arrList.Add(new customer
        {
            OrderId = "101",
            Name = "Lakshmi",
            City = "Chennai"
        });
        arrList.Add(new customer
        {
            OrderId = "102",
            Name = "Mala",
            City = "Madurai"
        });
        arrList.Add(new customer
        {
            OrderId="103",
            Name = "Vimala",
            City = "Coimbatore"
        });
        arrList1.Add(new orders
        {
            OrderId = "101",
            OrderName = "Books"
        });
        arrList1.Add(new orders
        {
            OrderId = "102",
            OrderName = "Notes"
        });
        arrList1.Add(new orders
        {
            OrderId = "104",
            OrderName = "Papers"
        });

        var query = from customer cus in arrList
                    orderby cus.Name descending
                    select cus;
        foreach (var cus in query)
        {
            Response.Write(cus.Name + " lives in " + cus.City + "<br>");
        }
        string CustName, CustCity;

        var query1 = from customer cus in arrList
                     join
                         orders ord in arrList1 on cus.OrderId
                         equals ord.OrderId
                     select new { CustName = cus.Name, CustCity = cus.City };
        foreach (var cus in query1)
        {
            Response.Write(cus.CustName + " lives in " + cus.CustCity + "<br>");
        }
    }
}
