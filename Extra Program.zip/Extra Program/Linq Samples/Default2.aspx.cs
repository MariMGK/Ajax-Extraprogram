﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    public class customer
    {
        public string Name { get;  set; }
        public string City { get; set; }
    }
    protected void Page_Load(object sender, EventArgs e)
    {
        ArrayList arrList = new ArrayList();
        arrList.Add(new customer
        {
            Name = "Lakshmi",
            City = "Chennai"
        });
        arrList.Add(new customer
        {
            Name = "Mala",
            City = "Madurai"
        });
        arrList.Add(new customer
        {
            Name = "Vimala",
            City = "Coimbatore"
        });
        var query = from customer cus in arrList
                    orderby cus.Name descending
                    select cus;
        foreach (var cus in query)
        {
            Response.Write(cus.Name + " lives in " + cus.City + "<br>");
        }
    }
}
