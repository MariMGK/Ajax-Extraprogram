﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class Default5 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        SqlConnection Myconn = new SqlConnection();
        Myconn.ConnectionString = "Data Source=CHN-00B90-FAC;Initial Catalog=emp;User ID=sa;Password=star;";
        DataSet ds = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter("Select * from Products", Myconn);
        Myconn.Open();
        da.Fill(ds);
        DataTable album = ds.Tables[0];
        var q = from d in album.AsEnumerable()
                select d;

        foreach (var i in q)
        {
            Response.Write(i.Field<string>("ProductName") + "<br>");
        }
    }
}
