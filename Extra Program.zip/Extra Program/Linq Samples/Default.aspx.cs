﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections.Generic;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string[] words = { "abc", "def", "ghi" };

        var CombinedWords =
            from w in words
            select w;
             
        Response.Write("The  list of words :");
        foreach (var w in CombinedWords)
        {
            Response.Write(w);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        int[] numbers={1,2,3,4,5,6,7,8,9,10 };
        var evenno = from num in numbers
                     where (num % 2) == 0
                     select num;
        int count = evenno.Count();
        Response.Write(count);
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        int[] all = { 1, 2, 3,  4, 5, 6, 7, 8, 9, 10 };
        var numbers = from num in all
                      select num;
        foreach (var no in numbers)
        {
            Response.Write(no + "\t");
        }
    }
  }