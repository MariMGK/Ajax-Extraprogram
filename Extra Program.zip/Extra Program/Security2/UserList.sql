CREATE TABLE UserList
(
  u_id INT NOT NULL IDENTITY,
  u_username VARCHAR( 100 ),
  u_password VARCHAR( 100 )
)
