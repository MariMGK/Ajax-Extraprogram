CREATE PROCEDURE DBRegister
(
  @username Varchar( 100 ),
  @password Varchar( 100 )
)
AS

IF EXISTS( SELECT u_id
  FROM UserList
  WHERE u_username=@username )
  RETURN - 1
ELSE
  INSERT UserList (
    u_username,
    u_password
    ) VALUES (
    @username,
    @password
    )
  RETURN @@IDENTITY
